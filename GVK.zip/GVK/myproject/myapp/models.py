
from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.IntegerField()
    #grade = models.CharField(max_length=50)
    grade = models.CharField(max_length=50, default="A")



    def __str__(self):
        return self.name
