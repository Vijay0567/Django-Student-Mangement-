from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from django.contrib.auth.decorators import login_required

def home(request):
    search = request.GET.get('search', '')
    grade = request.GET.get('grade', '')
    
    students = Student.objects.all()
    
    # Apply grade filter
    if grade:
        students = students.filter(grade=grade)
    
    # Apply search filter
    if search:
        students = students.filter(name__icontains=search) | Student.objects.filter(email__icontains=search)
        if grade:
            students = students.filter(grade=grade)
    
    return render(request, 'home.html', {'students': students, 'search': search, 'selected_grade': grade})


@login_required
def add_student(request):
    if request.method == 'POST':
        Student.objects.create(
            name=request.POST.get('name'),
            email=request.POST.get('email'),
            age=request.POST.get('age'),
            grade=request.POST.get('grade') 
        )
        return redirect('home')

    return render(request, 'add_student.html')


@login_required
def edit_student(request, id):
    student = get_object_or_404(Student, id=id)

    if request.method == 'POST':
        student.name = request.POST.get('name')
        student.email = request.POST.get('email')
        student.age = request.POST.get('age')
        student.grade = request.POST.get('grade')
        student.save()
        return redirect('home')

    return render(request, 'edit_student.html', {'student': student})


@login_required
def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.delete()
    return redirect('home')


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')
